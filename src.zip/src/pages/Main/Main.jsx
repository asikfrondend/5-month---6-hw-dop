import React from 'react'
import { UserList } from '../../Components'

const Main = () => {
  return (
    <div>
        <UserList/>
    </div>
  )
}

export default Main